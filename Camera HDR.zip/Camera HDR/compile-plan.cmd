@echo off
setlocal
pushd "%~dp0"
set "TECTONIC_CACHE_DIR=%CD%\Tools\tectonic\cache"
if exist "Tools\tectonic\fonts.conf" set "FONTCONFIG_FILE=%CD%\Tools\tectonic\fonts.conf"
if not exist "Tools\tectonic\tectonic.exe" (
  echo Portable Tectonic is missing. See Notes/index.html for setup instructions.
  popd
  exit /b 1
)
if not exist "Plan\Output\build" mkdir "Plan\Output\build"
"Tools\tectonic\tectonic.exe" --keep-logs --outdir "Plan\Output\build" "Plan\Source\main.tex"
if errorlevel 1 (
  echo Compilation failed. The previous published PDF has not been replaced.
  popd
  exit /b 1
)
copy /y "Plan\Output\build\main.pdf" "Plan\Output\Camera-HDR-Project-Plan.pdf" >nul
if errorlevel 1 (
  echo Cannot replace the output PDF. Close it in your viewer and retry.
  popd
  exit /b 1
)
echo PDF ready: %CD%\Plan\Output\Camera-HDR-Project-Plan.pdf
if /i "%~1"=="--open" start "" "Plan\Output\Camera-HDR-Project-Plan.pdf"
popd
exit /b 0
