"""Exact specular reflection check for the illustrated direct splitter.

All lengths below are an ASSIGNED example scale (10 old drawing units/mm),
not measured component dimensions. A perfect incoming converging wavefront,
zero-thickness surfaces, air, and constant lossless coatings are assumed.
Run directly for the reproducible numeric report; no external packages.
"""
from itertools import product
from math import acos, atan, cos, degrees, hypot, log2, pi, sin, sqrt
import json

FOCUS_Z = 47.0
PUPIL_RADIUS = 7.5
A_Z, B_Z = 20.0, 36.0
SENSOR_HALF = 3.5
A_HALF_X, A_HALF_Y = 7.0, 7.0
B_HALF_X, B_HALF_Y = 5.5, 5.5
FILTER_DISTANCE, FILTER_HALF = 3.0, 5.0
LEFT_X, RIGHT_X = A_Z-FOCUS_Z, FOCUS_Z-B_Z
INV_SQRT2 = 1 / sqrt(2)
A_NORMAL = (INV_SQRT2, 0.0, INV_SQRT2)
B_NORMAL = (-INV_SQRT2, 0.0, INV_SQRT2)


def dot(a, b): return sum(x*y for x, y in zip(a, b))
def add(a, b): return tuple(x+y for x, y in zip(a, b))
def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def mul(a, s): return tuple(x*s for x in a)
def norm(a): return sqrt(dot(a, a))
def unit(a): return mul(a, 1/norm(a))


def reflect(direction, normal):
    return sub(direction, mul(normal, 2*dot(direction, normal)))


def intersection(origin, direction, normal, offset):
    """Plane normal is unit length; plane equation dot(normal, point)=offset."""
    distance = (offset-dot(normal, origin))/dot(normal, direction)
    return add(origin, mul(direction, distance)), distance


def incidence(direction, normal):
    return degrees(acos(min(1.0, abs(dot(unit(direction), normal)))))


def trace(pupil_x, pupil_y=0.0, field_x=0.0, field_y=0.0):
    origin = (pupil_x, pupil_y, 0.0)
    focus = (field_x, field_y, FOCUS_Z)
    incoming = unit(sub(focus, origin))
    a, distance_a = intersection(origin, incoming, A_NORMAL, A_Z*INV_SQRT2)
    b, distance_b = intersection(origin, incoming, B_NORMAL, B_Z*INV_SQRT2)
    left_dir, right_dir = reflect(incoming, A_NORMAL), reflect(incoming, B_NORMAL)
    left, after_a = intersection(a, left_dir, (1,0,0), LEFT_X)
    right, after_b = intersection(b, right_dir, (1,0,0), RIGHT_X)
    left_filter, to_left_filter = intersection(a, left_dir, (1,0,0), LEFT_X+FILTER_DISTANCE)
    right_filter, to_right_filter = intersection(b, right_dir, (1,0,0), RIGHT_X-FILTER_DISTANCE)
    top_filter, to_top_filter = intersection(origin, incoming, (0,0,1), FOCUS_Z-FILTER_DISTANCE)
    filter_local = dict(left=(left_filter[2]-A_Z,left_filter[1]),
                        right=(right_filter[2]-B_Z,right_filter[1]),
                        top=(top_filter[0],top_filter[1]))
    full_length = norm(sub(focus, origin))
    # Independent analytic reflection of the complete image plane.
    expected_left = (LEFT_X, field_y, A_Z-field_x)
    expected_right = (RIGHT_X, field_y, B_Z+field_x)
    return dict(origin=origin, focus=focus, a=a, b=b, left=left, right=right,
                expected_left=expected_left, expected_right=expected_right,
                focus_error=max(norm(sub(left, expected_left)), norm(sub(right, expected_right))),
                path_lengths=(distance_a+after_a, distance_b+after_b, full_length),
                incidence_a=incidence(incoming, A_NORMAL), incidence_b=incidence(incoming, B_NORMAL),
                reflection_a=incidence(left_dir, A_NORMAL), reflection_b=incidence(right_dir, B_NORMAL),
                a_fraction=distance_a/full_length, b_fraction=distance_b/full_length,
                a_inside_aperture=abs(a[0]) <= A_HALF_X+1e-10 and abs(a[1]) <= A_HALF_Y+1e-10,
                b_inside_aperture=abs(b[0]) <= B_HALF_X+1e-10 and abs(b[1]) <= B_HALF_Y+1e-10,
                filters=dict(left=left_filter, right=right_filter, top=top_filter),
                filter_local=filter_local,
                filters_inside_apertures=all(abs(c) <= FILTER_HALF+1e-10 for p in filter_local.values() for c in p),
                filter_forward_order=(0 < to_left_filter < after_a and 0 < to_right_filter < after_b
                                      and distance_b < to_top_filter < full_length),
                forward_order=0 < distance_a < distance_b < full_length)


def power_shares(ra, ta, rb, tb):
    if min(ra,ta,rb,tb)<0 or ra+ta>1+1e-12 or rb+tb>1+1e-12:
        raise ValueError('Power coefficients must be nonnegative and passive')
    return dict(left=ra, right=ta*rb, top=ta*tb)


def continuous_bounds():
    """Conservative continuous proof over a pupil square enclosing the circle.

    P=(a,b,0), F=(h,v,f), |a|,|b|<=r and |h|,|v|<=s.
    tA=(A-a)/(f+h-a), xA=((f-A)*a+A*h)/(f+h-a).
    tB=(B+a)/(f-h+a), xB=((f-B)*a+B*h)/(f-h+a).
    Positive denominators and derivative signs give the extrema below.
    Each y=(1-t)*b+t*v has |y|<=r-(r-s)*min(t).
    These inequalities cover the whole domain; sampled rays only cross-check.
    """
    f,r,s = FOCUS_Z,PUPIL_RADIUS,SENSOR_HALF
    assert f > r+s and r > s and r < A_Z < B_Z < f-s
    ta = ((A_Z-r)/(f+s-r), (A_Z+r)/(f-s+r))
    tb = ((B_Z-r)/(f+s-r), (B_Z+r)/(f-s+r))
    xa = (-((f-A_Z)*r+A_Z*s)/(f-s+r), ((f-A_Z)*r+A_Z*s)/(f+s-r))
    xb = (-((f-B_Z)*r+B_Z*s)/(f+s-r), ((f-B_Z)*r+B_Z*s)/(f-s+r))
    ya, yb = r-(r-s)*ta[0], r-(r-s)*tb[0]
    a_x_margin, b_x_margin = A_HALF_X-max(map(abs,xa)), B_HALF_X-max(map(abs,xb))
    assert min(a_x_margin,A_HALF_Y-ya,b_x_margin,B_HALF_Y-yb) > 0
    assert 0 < ta[0] <= ta[1] < tb[0] <= tb[1] < 1

    # All optional filters are d before the sensor along its normal.
    # In the unfolded geometry t=(f-d)/f; transverse coordinates are
    # w=(d*a+(f-d)*h)/f and q=(d*b+(f-d)*v)/f.
    # Left: (LEFT_X+d,q,A-w); right: (RIGHT_X-d,q,B+w); top: (w,q,f-d).
    filter_fraction = (f-FILTER_DISTANCE)/f
    filter_half_bound = (FILTER_DISTANCE*r+(f-FILTER_DISTANCE)*s)/f
    assert filter_fraction > tb[1] and FILTER_HALF > filter_half_bound

    # A-reflected rays lie between A and its reflected focal plane, and
    # B-reflected rays between B and its reflected focal plane. Coordinate
    # extrema of each straight segment are at its endpoints.
    left_z = (min(A_Z-xa[1],A_Z-s), max(A_Z-xa[0],A_Z+s))
    right_z = (min(B_Z+xb[0],B_Z-s), max(B_Z+xb[1],B_Z+s))
    left_to_b_gap = B_Z-B_HALF_X-left_z[1]
    right_to_a_gap = right_z[0]-(A_Z+A_HALF_X)
    assert left_to_b_gap > 0 and right_to_a_gap > 0
    # Reflection in A preserves B's plane: the continuation crosses B at
    # x=A-f*tB, well outside B's finite clear rectangle.
    left_crosses_b_x = (A_Z-f*tb[1],A_Z-f*tb[0])
    assert left_crosses_b_x[1] < -B_HALF_X

    # The perpendicular infinite splitter planes meet at x=(A-B)/2.
    # Both finite segments start to its right; their nearest points are
    # their left edges, with overlapping y intervals.
    plane_cross_x = (A_Z-B_Z)/2
    assert plane_cross_x < min(-A_HALF_X,-B_HALF_X)
    surface_gap = hypot(A_HALF_X-B_HALF_X, B_Z-B_HALF_X-A_Z-A_HALF_X)
    left_filter_x, right_filter_x, top_filter_z = LEFT_X+FILTER_DISTANCE, RIGHT_X-FILTER_DISTANCE, f-FILTER_DISTANCE
    assert left_filter_x < -r and right_filter_x > r
    assert max(left_z[1],right_z[1]) < top_filter_z
    assert xa[1] < right_filter_x and xb[0] > left_filter_x

    # For these rectangle positions the closest B/filter points are B's
    # upper-right edge and the adjacent edges of the right and top filters.
    # Positive edge gaps also prove the finite optic surfaces do not touch.
    b_to_right_filter_gap = hypot(right_filter_x-B_HALF_X, B_HALF_X-FILTER_HALF)
    b_to_top_filter_gap = hypot(B_HALF_X-FILTER_HALF, top_filter_z-B_Z-B_HALF_X)
    assert B_HALF_X > FILTER_HALF and right_filter_x > B_HALF_X
    assert top_filter_z > B_Z+B_HALF_X
    # The unconstrained closest points on B would lie beyond its edge.
    assert (right_filter_x+FILTER_HALF)/2 > B_HALF_X
    assert (FILTER_HALF+top_filter_z-B_Z)/2 > B_HALF_X

    # Incident direction has dx,dy in [-(r+s),r+s], dz=f. This encloses
    # every circular-pupil ray; its angle bounds need not be attainable.
    u = r+s
    incidence_bound = (degrees(acos((f+u)/sqrt(2*(f*f+u*u)))),
                       degrees(acos((f-u)/sqrt(2*(f*f+2*u*u)))))
    return dict(
        domain='All |a|,|b|<=7.5 mm and |h|,|v|<=3.5 mm; pupil square conservatively encloses circular pupil.',
        a_fraction_bounds=ta, b_fraction_bounds=tb,
        a_x_bounds_mm=xa, a_abs_y_bound_mm=ya,
        b_x_bounds_mm=xb, b_abs_y_bound_mm=yb,
        a_projected_x_margin_mm=a_x_margin, a_y_margin_mm=A_HALF_Y-ya,
        a_surface_tangent_margin_mm=sqrt(2)*a_x_margin,
        b_projected_x_margin_mm=b_x_margin, b_y_margin_mm=B_HALF_Y-yb,
        b_surface_tangent_margin_mm=sqrt(2)*b_x_margin,
        a_clear_face_dimensions_mm=(2*sqrt(2)*A_HALF_X,2*A_HALF_Y),
        b_clear_face_dimensions_mm=(2*sqrt(2)*B_HALF_X,2*B_HALF_Y),
        minimum_forward_z_gap_mm=f*(tb[0]-ta[1]),
        left_bundle_z_bounds_mm=left_z, right_bundle_z_bounds_mm=right_z,
        left_branch_to_b_z_gap_mm=left_to_b_gap, right_branch_to_a_z_gap_mm=right_to_a_gap,
        left_branch_crosses_b_infinite_plane_x_mm=left_crosses_b_x,
        minimum_splitter_surface_separation_mm=surface_gap,
        filter_fraction=filter_fraction, filter_local_half_extent_bound_mm=filter_half_bound,
        filter_aperture_margin_mm=FILTER_HALF-filter_half_bound,
        minimum_b_to_right_filter_surface_separation_mm=b_to_right_filter_gap,
        minimum_b_to_top_filter_surface_separation_mm=b_to_top_filter_gap,
        main_bundle_to_right_filter_x_gap_lower_bound_mm=right_filter_x-r,
        main_bundle_to_left_filter_x_gap_lower_bound_mm=-r-left_filter_x,
        side_bundles_to_top_filter_z_gap_mm=top_filter_z-max(left_z[1],right_z[1]),
        full_domain_incidence_bounds_deg=incidence_bound,
        coverage='Full continuous pupil/field box clears the ideal rectangles and optional filters; no unwanted optic intersection.',
        limitation='Clearance between zero-thickness faces only; no glass, mounts, thickness, tolerance or mechanical packaging validation.')


def validate():
    bounds = continuous_bounds()
    pupil=[(0.0,0.0)]+[(PUPIL_RADIUS*cos(k*pi/4),PUPIL_RADIUS*sin(k*pi/4)) for k in range(8)]
    probes=[trace(a,b,h,v) for h in (-SENSOR_HALF,0,SENSOR_HALF) for v in (-SENSOR_HALF,0,SENSOR_HALF) for a,b in pupil]
    # Sixteen box corners are a bounded algebra cross-check, not a dense
    # sampling substitute for the continuous inequalities above.
    corners=[trace(a,b,h,v) for a,b,h,v in product((-PUPIL_RADIUS,PUPIL_RADIUS),
             (-PUPIL_RADIUS,PUPIL_RADIUS),(-SENSOR_HALF,SENSOR_HALF),(-SENSOR_HALF,SENSOR_HALF))]
    checked=probes+corners
    max_focus=max(r['focus_error'] for r in checked)
    max_path=max(max(r['path_lengths'])-min(r['path_lengths']) for r in checked)
    max_angle=max(max(abs(r['incidence_a']-r['reflection_a']),abs(r['incidence_b']-r['reflection_b'])) for r in checked)
    assert max_focus<1e-10 and max_path<1e-10 and max_angle<1e-10
    for ray in checked:
        assert ray['forward_order'] and ray['filter_forward_order']
        assert ray['a_inside_aperture'] and ray['b_inside_aperture'] and ray['filters_inside_apertures']
        for branch in ('a','b'):
            lo,hi=bounds[branch+'_x_bounds_mm']
            assert lo-1e-10 <= ray[branch][0] <= hi+1e-10
            assert abs(ray[branch][1]) <= bounds[branch+'_abs_y_bound_mm']+1e-10
            lo,hi=bounds[branch+'_fraction_bounds']
            assert lo-1e-10 <= ray[branch+'_fraction'] <= hi+1e-10
        assert all(abs(c) <= bounds['filter_local_half_extent_bound_mm']+1e-10
                   for p in ray['filter_local'].values() for c in p)
    return dict(
        model='Perfect convergence, exact specular reflection, zero-thickness surfaces, air; assigned illustrative mm scale.',
        sample_count=len(probes), bounded_corner_check_count=len(corners), validation_ray_count=len(checked),
        max_sensor_intersection_error_mm=max_focus,
        max_channel_path_difference_mm=max_path, max_reflection_angle_error_deg=max_angle,
        on_axis_cone_half_angle_deg=degrees(atan(PUPIL_RADIUS/FOCUS_Z)),
        on_axis_rays=[trace(a) for a in (-PUPIL_RADIUS,0,PUPIL_RADIUS)],
        ideal_90_10=power_shares(.9,.1,.9,.1), ideal_50_50=power_shares(.5,.5,.5,.5),
        left_light_loss_stops=-log2(.9), right_separation_from_left_stops=log2(10), top_separation_from_left_stops=log2(90),
        sensor_centers_mm=dict(left=(LEFT_X,0,A_Z),right=(RIGHT_X,0,B_Z),top=(0,0,FOCUS_Z)),
        filter_centers_mm=dict(left=(LEFT_X+FILTER_DISTANCE,0,A_Z),right=(RIGHT_X-FILTER_DISTANCE,0,B_Z),
                               top=(0,0,FOCUS_Z-FILTER_DISTANCE)),
        continuous_bounds=bounds,
        sample_rays_outside_A=sum(not r['a_inside_aperture'] for r in checked),
        sample_rays_outside_B=sum(not r['b_inside_aperture'] for r in checked),
        sample_rays_outside_filters=sum(not r['filters_inside_apertures'] for r in checked),
        full_field_examples=[trace(PUPIL_RADIUS,field_x=SENSOR_HALF),trace(-PUPIL_RADIUS,field_x=-SENSOR_HALF)],
        limitations='Assigned example dimensions only. No real lens prescription, glass/refraction, ND thickness, coating variation, diffraction, sensor cover stacks, mounts or manufacturing tolerances are modeled. ND filters are optional zero-thickness planes, not selected hardware.')


if __name__=='__main__':
    print(json.dumps(validate(),indent=2))
