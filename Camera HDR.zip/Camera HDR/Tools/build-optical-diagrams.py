"""Build static SVG teaching diagrams. All dimensions are illustrative paraxial distances.
Run from any directory with Python 3. No packages or network access required.
"""
from pathlib import Path
from html import escape

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'Notes' / 'assets'
ASSETS.mkdir(parents=True, exist_ok=True)
INK, MUTED = '#21373d', '#596e73'
PRIMARY, MID, HIGH = '#087c8a', '#b96610', '#7252a3'

def start(w, h, title, desc):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title desc">',
            f'<title id="title">{escape(title)}</title><desc id="desc">{escape(desc)}</desc>',
            '<rect width="100%" height="100%" fill="#fbfcfa"/>',
            '<style>text{font-family:Arial,Helvetica,sans-serif;fill:#21373d}.small{font-size:16px}.body{font-size:19px}.label{font-size:21px;font-weight:600}.title{font-size:30px;font-weight:600}.muted{fill:#596e73}.axis{stroke:#a9b7b8;stroke-width:1.5;stroke-dasharray:7 6}.leader{stroke:#789095;stroke-width:1.3;fill:none}</style>']

def text(a,x,y,s,cls='body',fill=None):
    a.append(f'<text x="{x}" y="{y}" class="{cls}"'+(f' style="fill:{fill}"' if fill else '')+f'>{escape(s)}</text>')

def line(a,x1,y1,x2,y2,stroke=INK,width=2,dash=None):
    a.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{width}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')

def path(a,pts,color,width=2,opacity=1):
    a.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" fill="none" stroke="{color}" stroke-width="{width}" opacity="{opacity}"/>')

def lens(a,x,y,vertical=True):
    # Thin-lens symbol, not a physical lens or housing outline.
    if vertical:
        line(a,x,y-45,x,y+45,'#4a7580',4)
        path(a,[(x-8,y-34),(x,y-45),(x+8,y-34)],'#4a7580')
        path(a,[(x-8,y+34),(x,y+45),(x+8,y+34)],'#4a7580')
    else:
        line(a,x-45,y,x+45,y,'#4a7580',4)
        path(a,[(x-34,y-8),(x-45,y),(x-34,y+8)],'#4a7580')
        path(a,[(x+34,y-8),(x+45,y),(x+34,y+8)],'#4a7580')

def sensor(a,x,y,vertical=True,color=PRIMARY):
    if vertical:
        a.append(f'<rect x="{x}" y="{y-30}" width="8" height="60" rx="2" fill="{color}"/>')
        for yy in range(y-27,y+27,9): line(a,x+9,yy,x+20,yy+7,'#8ba1a5',1)
    else:
        a.append(f'<rect x="{x-30}" y="{y}" width="60" height="8" rx="2" fill="{color}"/>')
        for xx in range(x-27,x+27,9): line(a,xx,y+9,xx+7,y+20,'#8ba1a5',1)

def dimension(a,x1,x2,y,label):
    line(a,x1,y,x2,y,'#83989d',1)
    for x in (x1,x2): line(a,x,y-6,x,y+6,'#83989d',1)
    text(a,(x1+x2)/2-len(label)*4,y-10,label,'small')

def arrow(a,x,y,d,color):
    pts = [(x-9,y-5),(x,y),(x-9,y+5)] if d=='right' else [(x-5,y-9),(x,y),(x+5,y-9)]
    path(a,pts,color,2)

# Top view: 5 drawing units/mm. The optical centerline distances are to scale.
# I=(40,40), L1=(90,40), A=(120,40), L2A=(190,40), SA=(240,40).
# B=(120,70), L2B=(160,70), SB=(210,70), L2C=(120,110), SC=(120,160).
a=start(1540,1090,'Three-sensor relay: top-view reference geometry',
        'A shared relay feeds one primary sensor and a weaker branch split into two highlight sensors. All three image paths have equal 200 mm unfolded relay length in an ideal thin-lens model. Sensor C faces upward in the diagram toward its downward incoming beam.')
text(a,55,52,'THREE-SENSOR RELAY / TOP VIEW','title')
text(a,55,86,'Paraxial reference geometry • not a mechanical drawing • ratios ideal','body')
text(a,55,126,'Thin-lens symbols show principal planes. Splitters are ideal zero-thickness surfaces.','small')
for pts in [[(100,270),(1300,270)],[(700,270),(700,870)],[(700,420),(1150,420)]]:
    path(a,pts,'#a9b7b8',1.3)
# Taking lens illustration, not dimensioned.
a.append('<rect x="77" y="220" width="56" height="100" rx="10" fill="#e7eeec" stroke="#779195"/>')
text(a,46,184,'Taking lens','label')
text(a,40,207,'position schematic','small')
for dy in [-18,0,18]:
    # Continue each ray straight through the empty image plane: it has no
    # optical surface and therefore must not introduce a bend.
    taking_height=270-dy*(300-133)/(550-300)
    line(a,133,taking_height,300,270,'#7d8d91',1.8)
line(a,300,223,300,317,'#4b646a',2,'5 5')
text(a,215,181,'Intermediate image','label')
text(a,238,206,'empty plane in air','small')
for dy in [-18,0,18]:
    path(a,[(300,270),(550,270+dy),(700+dy,270+dy)],'#647e84',2)
    path(a,[(700+dy,270+dy),(1050,270+dy),(1300,270)],PRIMARY,2.2)
    path(a,[(700+dy,270+dy),(700+dy,420+dy)],'#647e84',2)
    path(a,[(700+dy,420+dy),(900,420+dy),(1150,420)],MID,2.2)
    path(a,[(700+dy,420+dy),(700+dy,620),(700,870)],HIGH,2.2)
for x,y in [(700,270),(700,420)]:
    line(a,x-29,y-29,x+29,y+29,'#2e555f',5)
for x,y in [(550,270),(1050,270),(900,420)]: lens(a,x,y)
lens(a,700,620,False)
sensor(a,1300,270,True,PRIMARY); sensor(a,1150,420,True,MID); sensor(a,700,870,False,HIGH)
text(a,480,180,'L1 / collimator','label');text(a,500,205,'f = 50 mm','small')
text(a,655,180,'Splitter A','label');text(a,645,205,'R10 / T90','small')
text(a,987,180,'L2A / f = 50 mm','label')
text(a,1242,180,'Sensor A','label');text(a,1245,207,'90% • primary','body',PRIMARY)
text(a,779,242,'90% transmitted','small',PRIMARY)
text(a,710,331,'10% reflected','small')
text(a,503,409,'Splitter B','label');text(a,512,437,'R90 / T10','small')
line(a,627,421,667,421,'#789095',1.3)
text(a,930,358,'L2B','label');text(a,930,381,'f = 50 mm','small')
text(a,1191,410,'Sensor B','label');text(a,1191,439,'9% • highlights','body',MID)
text(a,766,488,'90% of the 10% branch','small',MID)
text(a,735,545,'10% of the 10% branch','small',HIGH)
text(a,775,615,'L2C / f = 50 mm','label');text(a,775,644,'axis points downward','small')
text(a,775,865,'Sensor C','label');text(a,775,894,'1% • extreme highlights','body',HIGH)
text(a,775,922,'Sensor face is perpendicular to this axis.','small')
arrow(a,850,270,'right',PRIMARY);arrow(a,700,360,'down','#647e84');arrow(a,1000,420,'right',MID);arrow(a,700,750,'down',HIGH)
dimension(a,300,550,344,'50 mm')
dimension(a,550,1050,148,'100 mm along A path')
dimension(a,1050,1300,344,'50 mm')
dimension(a,900,1150,515,'50 mm')
line(a,628,620,628,870,'#83989d',1)
line(a,622,620,634,620,'#83989d',1);line(a,622,870,634,870,'#83989d',1)
text(a,550,751,'50 mm','small')
a.append('<rect x="55" y="545" width="450" height="360" rx="12" fill="#edf3f0" stroke="#cbd9d5"/>')
text(a,78,582,'One consistent reference layout','label')
for yy,s in [(618,'Image plane → L1: 50 mm'),(654,'L1 → any L2: 100 mm unfolded'),(690,'Any L2 → its sensor: 50 mm'),(735,'Relay length per branch: 200 mm'),(771,'Magnification magnitude: 1×'),(816,'B adds no extra relay length:'),(843,'its final lens sits closer to the split.')]: text(a,78,yy,s,'body')
text(a,55,970,'Geometry is drawn at 5 units/mm after the intermediate image; optic symbols and apertures are not to scale.','small')
text(a,55,1000,'Real lens groups, glass thickness, sensor cover stacks, vignetting and mounts require a separate optical/mechanical design.','small')
text(a,55,1030,'Rays represent ONE image point. Equal middle-section lengths are a choice here, not a requirement for collimation.','small')
a.append('</svg>')
(ASSETS/'three-sensor-relay-layout.svg').write_text('\n'.join(a),encoding='utf-8')

# Unfolded exact thin-lens model: u in mm from image plane; f1=f2=50.
# Propagation to L1, thin lens, propagation100, thin lens, propagation50.
a=start(1380,730,'Unfolded 1:1 relay with two image points',
        'Two bundles from distinct intermediate image points pass through equal 50 mm focal length lenses. A 50/100/50 mm arrangement forms an inverted unit-magnification image. Rays are calculated with the paraxial thin-lens equations.')
text(a,45,52,'UNFOLDED VIEW / WHAT THE LENSES DO','title')
text(a,45,87,'All three folded branches share this first-order model. Reflection-dependent orientation is handled separately.','small')
sx, sy, origin, cy = 5.5, 5.5, 120, 330
px=lambda u: origin+u*sx
py=lambda h: cy-h*sy
line(a,px(0)-20,cy,px(200)+30,cy,'#b3c1c2',1.2,'6 6')
for u in [0,200]: line(a,px(u),cy-90,px(u),cy+90,'#4b646a',1.5,'5 5')
for u in [50,150]:
    line(a,px(u),cy-75,px(u),cy+75,'#4a7580',4)
    path(a,[(px(u)-8,cy-64),(px(u),cy-75),(px(u)+8,cy-64)],'#4a7580')
    path(a,[(px(u)-8,cy+64),(px(u),cy+75),(px(u)+8,cy+64)],'#4a7580')
for h,color in [(0,PRIMARY),(4,HIGH)]:
    for h1 in [-5,0,5]:
        theta0=(h1-h)/50
        theta1=theta0-h1/50
        h2=h1+100*theta1
        theta2=theta1-h2/50
        h3=h2+50*theta2
        if abs(h3+h)>1e-10: raise ValueError('Relay did not image the input plane')
        path(a,[(px(0),py(h)),(px(50),py(h1)),(px(150),py(h2)),(px(200),py(h3))],color,2.2,.8)
    for u,hh in [(0,h),(200,-h)]: a.append(f'<circle cx="{px(u)}" cy="{py(hh)}" r="5" fill="{color}"/>')
text(a,60,170,'Intermediate','label');text(a,60,197,'image plane','label')
text(a,334,170,'L1','label');text(a,334,197,'f = 50 mm','small')
text(a,890,170,'L2','label');text(a,890,197,'f = 50 mm','small')
text(a,1165,170,'Sensor plane','label')
text(a,563,170,'Splitters go in this region','label')
text(a,563,197,'Parallel rays per field point','small')
text(a,563,222,'Different points have different angles.','small')
dimension(a,px(0),px(50),462,'50 mm')
dimension(a,px(50),px(150),462,'100 mm')
dimension(a,px(150),px(200),462,'50 mm')
text(a,55,523,'TEAL: on-axis image point','label',PRIMARY)
text(a,55,556,'VIOLET: a second point, drawn at +4 mm → −4 mm','label',HIGH)
text(a,55,601,'Calculation: propagate h′ = h + dθ; at a thin lens θ′ = θ − h/f. Each branch images h to −h.','body')
text(a,55,639,'Distances refer to ideal principal planes. Rays test the paraxial model only, not real glass or wide-field performance.','small')
text(a,55,673,'A relay does not focus the entire photograph to one spot: every scene point forms its own sensor point.','small')
a.append('</svg>')
(ASSETS/'relay-focus-unfolded.svg').write_text('\n'.join(a),encoding='utf-8')

# Additional explanatory visual: axial adjustment and tilted sensor, intentionally schematic.
a=start(1200,500,'Sensor plane adjustment and tilt',
        'Two schematic mounting examples compare a sensor centered on its image plane with a tilted sensor. Axial translation adjusts focus; tip and tilt align the entire plane.')
text(a,45,50,'SENSOR MOUNT / FOCUS THE WHOLE SURFACE','title')
for ox,title,tilt in [(55,'Aligned sensor',False),(650,'Tilted sensor',True)]:
    text(a,ox,112,title,'label')
    lens(a,ox+60,250)
    line(a,ox+355,155,ox+355,345,'#7a9398',1.5,'5 5')
    for end in [205,295]:
        for starty in [220,280]:
            if tilt:
                # Intersect the ray with the actual tilted surface. Solid rays
                # stop at the detector; dashed extensions show missed focus.
                # Detector x = ox+326 + (y-165)*58/170.
                k=58/170
                t=(326-60+k*(starty-165))/(295-k*(end-starty))
                hitx, hity=ox+60+295*t, starty+(end-starty)*t
                line(a,ox+60,starty,hitx,hity,PRIMARY,1.6)
                if t<1: line(a,hitx,hity,ox+355,end,PRIMARY,1.6,'4 4')
                a.append(f'<circle cx="{hitx}" cy="{hity}" r="3" fill="{PRIMARY}"/>')
            else:
                line(a,ox+60,starty,ox+355,end,PRIMARY,1.6)
    if tilt: line(a,ox+326,165,ox+384,335,HIGH,7)
    else: line(a,ox+355,165,ox+355,335,PRIMARY,7)
    text(a,ox+232,374,'Intended image plane','small')
    if tilt: text(a,ox,397,'Dashed rays: hypothetical continuation past sensor.','small')
    text(a,ox,424,'Axial adjustment sets focus.' if not tilt else 'Tip/tilt aligns edges as well as center.','body')
text(a,45,474,'Mount concept only: show sensor surface alignment, not a tolerance or mechanical design.','small')
a.append('</svg>')
(ASSETS/'sensor-plane-adjustment.svg').write_text('\n'.join(a),encoding='utf-8')
# Direct-split drawings use their separately validated vector model.
from build_direct_split_diagrams import build as build_direct_split
build_direct_split(ASSETS)
print('Built five static SVG diagrams. Relay and direct-split model calculations passed.')
