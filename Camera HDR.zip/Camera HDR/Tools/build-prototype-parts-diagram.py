"""Dimensioned stock-blank comparison, not an optical or printable CAD design."""
from pathlib import Path
from math import sqrt, atan, degrees
from build_direct_split_diagrams import start, text, path, rect, dim, finish, PRIMARY, MID

out=Path(__file__).resolve().parents[1]/'Notes'/'assets'/'prototype-optics-parts.svg'
a=start(1440,1000,'Prototype optics: stock mirror size and lens choices',
        'A 36 by 25 millimetre stock plate is larger than the modeled clear aperture. Even with its shorter side in the folding plane, two such plates intersect at sixteen millimetre center spacing. Twenty-two millimetres is shown only as an example of separating blank center surfaces. Manual Nikon F lenses offer a longer nominal flange distance than the owned Sony E lens.')
text(a,45,52,'REAL PARTS / DESIGN THE BODY AROUND THE WHOLE OPTIC','title')
text(a,45,88,'Sourcing study • 23 October 2026 • measured drawings still needed before printing a fitted enclosure')

text(a,55,158,'Stock plate: 36 × 25 × 1 mm','label')
text(a,55,190,'Short 25 mm edge in the folding plane','small')
# Face-on view: long dimension out of the optical drawing plane.
sc=8;cx,cy=230,380
rect(a,cx-12.5*sc,cy-18*sc,25*sc,36*sc,'#eef1ee','#536d73',0)
rect(a,cx-9.8995*sc,cy-7*sc,19.799*sc,14*sc,'#c4e0da',PRIMARY,0)
dim(a,(130,555),(330,555),'25 mm along face',164,580)
dim(a,(365,236),(365,524),'36 mm',378,390)
text(a,55,625,'Inner area: earlier A clear aperture','small')
text(a,55,653,'19.80 × 14 mm; not the glass boundary','small')
text(a,55,681,'Coating clear-area drawing still required.','small')

hx=25/(2*sqrt(2))
for center_x,gap,title,subtitle in [(730,16,'16 mm centers: collision','The previous spacing cannot hold these blanks.'),(1180,22,'22 mm centers: size example','Not a validated lens / sensor layout.')]:
    text(a,center_x-185,158,title,'label');text(a,center_x-185,190,subtitle,'small')
    mp=lambda x,z:(center_x+10*x,610-10*z)
    for z,sign,col in [(10,-1,PRIMARY),(10+gap,1,MID)]:
        path(a,[mp(-hx,z-sign*hx),mp(hx,z+sign*hx)],col,4)
        px,py=mp(0,z);a.append(f'<circle cx="{px}" cy="{py}" r="4" fill="{col}"/>')
    dim(a,mp(12,10),mp(12,10+gap),f'{gap} mm',center_x+130,610-10*(10+gap/2))
    if gap==16:
        px,py=mp(-gap/2,10+gap/2)
        a.append(f'<circle cx="{px}" cy="{py}" r="13" fill="none" stroke="#b14835" stroke-width="2"/>')
        text(a,center_x-185,625,'Both center surfaces cross here.','small')
        text(a,center_x-185,653,'Thickness and holders add more space.','small')
    else:
        text(a,center_x-185,625,'Blank center surfaces clear by 4.32 mm.','small')
        text(a,center_x-185,653,'Glass, frames and ray clearance still open.','small')
    text(a,center_x-185,681,'25 mm at 45° projects to 17.68 mm.','small')

rect(a,45,725,1350,206,'#eef4f1')
text(a,70,765,'Main-lens shortlist','label')
for x,title,lines in [(70,'Nikon 50 mm f/1.8D', ['Manual focus + aperture ring','F mount: 46.5 mm flange distance','7 mm sensor width → 8.0° horizontal view']), (520,'Nikon 28 mm f/2.8D',['Wider alternative; manual controls','F mount: 46.5 mm flange distance','7 mm sensor width → 14.3° horizontal view']), (970,'Owned Sony 18–55 mm',['Assuming SEL1855 E-mount kit lens','E mount: 18 mm flange distance','Control + rear-space study needed'])]:
    text(a,x,806,title,'body')
    for i,line in enumerate(lines):text(a,x,840+i*29,line,'small')
text(a,45,976,'Flange distance is measured from the mount, not the rear glass or the ideal pupil plane. It does not guarantee free space for the splitters.','small')
finish(a,out)
assert hx>8 and 22>2*hx
print({'stock_half_span_mm':hx,'minimum_center_spacing_zero_thickness_mm':2*hx,
       'example_22mm_surface_gap_mm':22-2*hx,
       'horizontal_fov_7mm_sensor_deg':{f:2*degrees(atan(7/(2*f))) for f in (50,28)}})
