"""Static, dimensioned figures from the direct splitter's ideal geometric model."""
from html import escape
from math import sqrt
from pathlib import Path
import direct_split_model as model

INK, PRIMARY, MID, HIGH = '#21373d', '#087c8a', '#b96610', '#7252a3'


def start(w,h,title,desc):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title desc">',f'<title id="title">{escape(title)}</title><desc id="desc">{escape(desc)}</desc>', '<rect width="100%" height="100%" fill="#fbfcfa"/>','<style>text{font-family:Arial,Helvetica,sans-serif;fill:#21373d}.title{font-size:29px;font-weight:600}.label{font-size:22px;font-weight:600}.body{font-size:19px}.small{font-size:16px}</style>']


def text(a,x,y,s,cls='body',color=INK):
    a.append(f'<text x="{x}" y="{y}" class="{cls}" style="fill:{color}">{escape(s)}</text>')


def path(a,points,color=INK,width=2,dash=None,opacity=1):
    a.append('<polyline points="'+' '.join(f'{x:.4f},{y:.4f}' for x,y in points)+f'" fill="none" stroke="{color}" stroke-width="{width}" opacity="{opacity}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')


def rect(a,x,y,w,h,fill,stroke='#cbd8d3',radius=8):
    a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}"/>')


def dim(a,p,q,label,tx,ty):
    path(a,[p,q],'#80969b',1.2)
    tick=(0,5) if abs(q[0]-p[0])>abs(q[1]-p[1]) else (5,0)
    for x,y in (p,q): path(a,[(x-tick[0],y-tick[1]),(x+tick[0],y+tick[1])],'#80969b',1.2)
    text(a,tx,ty,label,'small')


def finish(a,out):
    a.append('</svg>'); out.write_text('\n'.join(a),encoding='utf-8')


def build(assets):
    model.validate()
    L,A,B=model.FOCUS_Z,model.A_Z,model.B_Z
    left_x,right_x=A-L,L-B
    mp=lambda p:(680+12*p[0],900-12*p[2])
    a=start(1600,1120,'Revised direct split: full field and independent filter positions','Two larger separated 45 degree zero-thickness splitters pass every pupil ray for a seven by seven millimetre image in the ideal air model. Left is the ninety percent main branch, right nine percent, top one percent before filters. Dashed bars reserve filter planes. No real glass or mounts are modeled.')
    text(a,45,52,'DIRECT SPLIT / FULL-FIELD GEOMETRY + BRANCH FILTERS','title')
    text(a,45,88,'Illustrative 7 × 7 mm sensors • 15 mm pupil • exact reflection in air • dimensions in mm')
    text(a,45,151,'Solid rays: center field. Dashed rays: opposite image edges. Colors identify branches, not light intensity.','small')
    for h in (-3.5,3.5,0):
        for px in (-7.5,0,7.5):
            r=model.trace(px,field_x=h); alpha=0.44 if h else 0.95; dash='5 4' if h else None
            path(a,[mp(r['origin']),mp(r['a']),mp(r['b'])],'#647e84',1.5,dash,alpha)
            path(a,[mp(r['b']),mp(r['focus'])],HIGH,1.5,dash,alpha)
            path(a,[mp(r['a']),mp(r['left'])],PRIMARY,1.8,dash,alpha)
            path(a,[mp(r['b']),mp(r['right'])],MID,1.8,dash,alpha)
    for z,hx,sign in [(A,model.A_HALF_X,-1),(B,model.B_HALF_X,1)]:
        path(a,[mp((-hx,0,z-sign*hx)),mp((hx,0,z+sign*hx))],'#2e555f',5)
    for x,z,c in [(left_x,A,PRIMARY),(right_x,B,MID)]: path(a,[mp((x,0,z-3.5)),mp((x,0,z+3.5))],c,7)
    path(a,[mp((-3.5,0,L)),mp((3.5,0,L))],HIGH,7)
    for x,z in [(left_x+3,A),(right_x-3,B)]: path(a,[mp((x,0,z-5)),mp((x,0,z+5))],'#596e73',3,'7 5')
    path(a,[mp((-5,0,L-3)),mp((5,0,L-3))],'#596e73',3,'7 5')
    path(a,[mp((-7.5,0,0)),mp((7.5,0,0))],'#4a7580',4)
    for x in (-7.5,0,7.5): path(a,[mp((x,0,-5)),mp((x,0,0))],'#647e84',1.5)
    for x,y,s,cls,col in [(52,576,'LEFT · 90%','label',PRIMARY),(52,608,'Main / low-light branch','body',INK),(52,637,'Center (−27, 20)','small',INK),(52,666,'Sensor faces right','small',INK),(852,424,'RIGHT · 9%','label',MID),(852,455,'Center (11, 36)','small',INK),(852,484,'Sensor faces left','small',INK),(775,283,'TOP · 1%','label',HIGH),(775,314,'Center (0, 47)','small',INK),(775,343,'Sensor faces down','small',INK)]: text(a,x,y,s,cls,col)
    text(a,55,227,'B · 90% reflected / 10% transmitted','label')
    text(a,55,257,'Center z = 36; clear face 15.56 × 11 mm','small')
    path(a,[(442,270),(540,300),mp((-4.5,0,B-4.5))],'#80969b',1.2)
    text(a,55,821,'A · 90% reflected / 10% transmitted','label')
    text(a,55,851,'Center z = 20; clear face 19.80 × 14 mm','small')
    path(a,[(493,828),(560,805),mp((5.5,0,A-5.5))],'#80969b',1.2)
    text(a,55,725,'Dashed bars: optional ND / clear carrier','small')
    path(a,[(365,728),mp((left_x+3,0,A-4.5))],'#80969b',1.1)
    for pts,c in [([(671,954),(680,943),(689,954)],'#647e84'),([(470,651),(459,660),(470,669)],PRIMARY),([(756,459),(767,468),(756,477)],MID),([(671,397),(680,386),(689,397)],HIGH)]: path(a,pts,c)
    text(a,819,893,'Ideal input pupil / lens plane')
    text(a,819,921,'z = 0; not a physical lens drawing','small')
    dim(a,mp((-7.5,0,-7)),mp((7.5,0,-7)),'15 mm pupil',620,1009)
    for p,q,s,x,y in [((1045,660),(1045,900),'20 mm',1060,790),((1045,468),(1045,660),'16 mm',1060,570),((1045,336),(1045,468),'11 mm',1060,392),((356,769),(680,769),'27 mm from A axis to left image',380,790),((680,566),(812,566),'11 mm',710,589)]: dim(a,p,q,s,x,y)
    for y,h,title,lines,fill in [(160,245,'Angles and focus',[(239,'Both surfaces: 45° to the input axis'),(270,'Axis rays turn through 90°.'),(309,'On-axis incidence: 35.93°–54.07°'),(340,'Full boxed field bound: 31.83°–59.06°'),(378,'Incidence is measured from the normal.')],'#eef4f1'),(434,270,'Full-field aperture result',[(513,'All rays to a 7 × 7 mm image fit.'),(544,'Bound covers the whole 15 mm pupil.'),(583,'Splitter surfaces: 3.81 mm apart'),(614,'Each branch misses the other splitter.'),(653,'Zero-thickness optical clearance only.'),(681,'Frames and real glass still need a design.')],'#eef4f1'),(733,270,'Space for independent ND',[(813,'Reserve a plane 3 mm before each sensor.'),(844,'10 × 10 mm clear area per branch.'),(875,'Required bound: 7.511 × 7.511 mm.'),(916,'Left defaults clear for low light.'),(947,'90 / 9 / 1 is BEFORE extra attenuation.'),(978,'Glass changes focus; location study only.')],'#f4f1e8')]:
        rect(a,1140,y,415,h,fill);text(a,1160,y+40,title,'label')
        for yy,s in lines: text(a,1160,yy,s,'small')
    text(a,45,1057,'Calculated geometry; hardware not selected. The ideal 47 mm image distance is not an E-mount flange-back specification.','small')
    text(a,45,1087,'No branch lenses in this ideal model. Real splitters, filters and sensor windows may require focus adjustment and correction.','small')
    finish(a,assets/'direct-converging-split.svg')

    a=start(1500,1030,'Continuous full-field coverage and reserved ND apertures','Face-on views of clear apertures. Inner rectangles conservatively bound every pupil ray across the complete square image field. The larger pupil square contains the true circular pupil. These are geometric bounds, not illumination maps.')
    text(a,45,53,'FULL IMAGE COVERAGE / FACE-ON APERTURE BOUNDS','title')
    text(a,45,90,'Colored regions bound every pupil ray to every point of the 7 × 7 mm image; these are not illumination maps.')
    plots=[(285,'Splitter A',7*sqrt(2),7,-272.5/51*sqrt(2),272.5/43*sqrt(2),272.5/43,'19.80 × 14 mm clear','u = √2 x along the tilted face'),(765,'Splitter B',5.5*sqrt(2),5.5,-208.5/43*sqrt(2),208.5/51*sqrt(2),208.5/43,'15.56 × 11 mm clear','u = √2 x along the tilted face'),(1245,'Each ND / clear position',5,5,-176.5/47,176.5/47,176.5/47,'10 × 10 mm clear','Local horizontal / vertical coordinates')]
    for cx,title,hu,hv,lo,hi,by,size,axis in plots:
        sc=18;cy=395
        text(a,cx-210,176,title,'label');text(a,cx-210,208,size)
        rect(a,cx-hu*sc,cy-hv*sc,2*hu*sc,2*hv*sc,'#f4f7f3','#2e555f',0)
        rect(a,cx+lo*sc,cy-by*sc,(hi-lo)*sc,2*by*sc,'#c4e0da',PRIMARY,0)
        path(a,[(cx-hu*sc-10,cy),(cx+hu*sc+10,cy)],'#80969b',1,'4 4')
        path(a,[(cx,cy-hv*sc-10),(cx,cy+hv*sc+10)],'#80969b',1,'4 4')
        text(a,cx-210,565,axis,'small')
    for x,y,s in [(75,609,'x footprint: −5.343 to +6.337 mm'),(75,638,'|y| ≤ 6.337 mm; clear |y| ≤ 7 mm'),(555,609,'x footprint: −4.849 to +4.088 mm'),(555,638,'|y| ≤ 4.849 mm; clear |y| ≤ 5.5 mm'),(1035,609,'Both local coordinates: ±3.755 mm'),(1035,638,'1.245 mm minimum margin to an edge')]: text(a,x,y,s,'small')
    rect(a,45,691,1410,252,'#eef4f1');text(a,70,733,'Why this covers a continuous image','label')
    for y,s in [(773,'Enclose the circular pupil in a square: a,b ∈ [−7.5,+7.5]. Let the whole image be h,v ∈ [−3.5,+3.5].'),(807,'Intersections are linear-fractional functions with positive denominators; their extrema occur at box corners.'),(841,'Every ray meets A before B. Reflected paths clear the other splitter and the other filter / sensor planes.'),(875,'A filter 3 mm before the image unfolds to w = (3a + 44h)/47 and q = (3b + 44v)/47.'),(916,'Margins cover optical apertures only. Mounts, alignment error, glass, diffraction and image quality are not included.')]: text(a,70,y,s,'body' if y==773 else 'small')
    text(a,45,989,'Old sketch: 10 mm splitter spacing and 9 mm projected spans clipped edges. Revised: 16 mm spacing and larger clear apertures.','small')
    finish(a,assets/'direct-split-aperture-check.svg')


if __name__=='__main__':
    build(Path(__file__).resolve().parents[1]/'Notes'/'assets')
    print('Built revised geometry and continuous aperture-bound SVGs.')
